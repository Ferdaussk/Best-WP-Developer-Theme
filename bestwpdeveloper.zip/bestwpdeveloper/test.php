<?php get_header(); ?>




<?php bestwpdevelopertd_blog_pagination(); ?>





<?php get_footer(); ?>