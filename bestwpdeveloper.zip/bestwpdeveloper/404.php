<?php 
get_header();
?>

<!-- Here have all header and menu section. location another-navigation.php -->
<?php get_template_part("templates/common/another-navigation"); ?>




<h1>404</h1>




<?php
get_footer();
?>